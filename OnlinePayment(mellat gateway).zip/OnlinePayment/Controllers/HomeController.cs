﻿using Microsoft.AspNetCore.Mvc;
using OnlinePayment.Models;
using OnlinePayment.Services;
using System.Diagnostics;

namespace OnlinePayment.Controllers
{
	public class HomeController : Controller
	{
		private readonly ILogger<HomeController> _logger;
		private readonly IBehPardakht _behPardakht;

		public HomeController(ILogger<HomeController> logger,
			IBehPardakht behPardakht)
		{
			_logger = logger;
			_behPardakht = behPardakht;
		}

		public IActionResult Index()
		{
			return View();
		}

		public IActionResult Privacy()
		{
			return View();
		}

		[ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
		public IActionResult Error()
		{
			return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
		}


		public IActionResult Pay()
		{
			
			var dateTime = DateTime.Now;
			var time = DateTime.Now.TimeOfDay;

			var result = _behPardakht.PayRequest(1000, dateTime, time, "", 1, null);

			//var x = 16;

			return Ok();

		}
	}
}