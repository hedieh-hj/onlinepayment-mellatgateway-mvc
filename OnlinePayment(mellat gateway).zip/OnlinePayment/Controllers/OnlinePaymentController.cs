﻿using Microsoft.AspNetCore.Mvc;
using OnlinePayment.Services;

namespace OnlinePayment.Controllers
{
	public class OnlinePaymentController : Controller
	{
		private readonly IBehPardakht _behPardakht;

		public OnlinePaymentController(IBehPardakht behPardakht)
		{
			_behPardakht = behPardakht;
		}

		public IActionResult Index()
		{
			return View();
		}


		[HttpPost]
		public IActionResult Pay()
		{
			var dateTime = DateTime.Now;
			var time = DateTime.Now.TimeOfDay;

			var result = _behPardakht.PayRequest(1000, dateTime, time, "", 1, null);

			var x = 16;

			return Ok();

		}
	}
}
