﻿namespace OnlinePayment.Services
{
	public interface IBehPardakht
	{
		//Task<string?> PayRequest(long amount, DateTime payDate, TimeSpan time, string additionalInfo, long payId, int? payType);

		string PayRequest(long amount, DateTime payDate, TimeSpan time, string additionalInfo, long payId, int? payType);
	}
}
