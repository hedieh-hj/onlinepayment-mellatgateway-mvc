﻿using MellatGatewayRefrence;
using System.Security.Cryptography.X509Certificates;

namespace OnlinePayment.Services
{
	public class BehPardakht :IBehPardakht
	{
		public const long TerminalId = 4885993;
		public const string behpardakht_usename = "armoonsoft1398";
		public const string behpardakht_password = "33669001";
		public const string callbackUrl = "https://armoonsoft.ir/BankMellat/PaymentCallback";

		public string PayRequest(long amount, DateTime payDate, TimeSpan time, string additionalInfo, long payId, int? payType )
		{
			long payerId = 0; //always 0
			payerId = 0;

			try
			{
			
				PaymentGatewayClient client = new PaymentGatewayClient();

				var response = client.bpPayRequestAsync(
					TerminalId,
					behpardakht_usename,
					behpardakht_password,
					0, //long oderid
					amount,
					payDate.Year.ToString() + payDate.Month.ToString().PadLeft(2, '0') + payDate.Day.ToString().PadLeft(2, '0'),
					payDate.Hour.ToString().PadLeft(2, '0') + payDate.Minute.ToString().PadLeft(2, '0') + payDate.Second.ToString().PadLeft(2, '0'),
					additionalInfo,
					callbackUrl,
					(payerId).ToString(),
					null, //string mobileNo
					null, //string encpan
					null, //string panhidenmode
					null, //string cartitem
					null  //string enc
				).Result;
												
				var _error = ResCodeFarsi(response.Body.@return);
				
				return _error;				
			}
			catch (Exception)
			{
				throw;
			}			
		}


		public string ResCodeFarsi(string ResCode)
		{
			switch (ResCode)
			{
				//خطاهای به‌پرداخت
				case "0":
					return "تراکنش با موفقیت انجام شد";
				case "11":
					return "شماره کارت نامعتبر است";
				case "12":
					return "موجودی کافی نیست";
				case "13":
					return "رمز نادرست است";
				case "14":
					return "تعداد دفعات وارد کردن رمز بیش از حد مجاز است";
				case "15":
					return "کارت نامعتبر است";
				case "16":
					return "دفعات برداشت وجه بیش از حد مجاز است";
				case "17":
					return "کاربر از انجام تراکنش منصرف شده است";
				case "18":
					return "تاریخ انقضای کارت گذشته است";
				case "19":
					return "مبلغ برداشت وجه بیش از حد مجاز است";
				case "111":
					return "صادر کننده کارت نامعتبر است";
				case "112":
					return "خطای سوییچ صادر کننده کارت";
				case "113":
					return "پاسخی از صادر کننده کارت دریافت نشد";
				case "114":
					return "دارنده کارت مجاز به انجام این تراکنش نیست";
				case "21":
					return "پذیرنده نامعتبر است";
				case "23":
					return "خطای امنیتی رخ داده است";

				case "24":
					return "اطلاعات کاربری پذیرنده نامعتبر است";

				case "25":
					return "مبلغ نامعتبر است";


				case "31":
					return "پاسخ نامعتبر است";
				case "32":
					return "فرمت اطلاعات وارد شده صحیح نمی باشد";

				case "33":
					return "حساب نامعتبر است";
				case "34":
					return "خطای سیستمی";
				case "35":
					return "تاریخ نامعتبر است";
				case "41":
					return "شماره درخواست تکراری است";
				case "42":
					return "تراکنش sale یافت نشد";
				case "43":
					return "قبلا درخواست verify داده شده است";
				case "44":
					return "درخواست verify یافت نشد";
				case "45":
					return "تراکنش settle شده است";
				case "46":
					return "تراکنش settle نشده است";
				case "47":
					return "تراکنش settle یافت نشد";
				case "48":
					return "تراکنش reverse شده است";
				case "49":
					return "تراکنش refund یافت نشد";
				case "412":
					return "شناسه قبض نادرست است";
				case "413":
					return "شناسه پرداخت نادرست است";
				case "414":
					return "سازمان صادر کننده قبض نامعتبر است";
				case "415":
					return "زمان جلسه کاری به پایان رسیده است";
				case "416":
					return "خطا در ثبت اطلاعات";
				case "417":
					return "شناسه پرداخت کننده نادرست است";
				case "418":
					return "اشکال در تعریف اطلاعات مشتری";
				case "419":
					return "تعداد دفعات ورود اطلاعات از حد مجاز گذشته است";
				case "421":
					return "IP نا معتبر است";
				case "51":
					return "تراکنش تکراری است";
				case "54":
					return "تراکنش مرجع موجود نیست";
				case "55":
					return "تراکنش نامعتبر است";
				case "61":
					return "خطا در واریز";

				//خطاهای سیستمی

				case "-900":
					return "خطا در  تطبیق اطلاعات پرداخت با به پرداخت رخ داد";
				case "-901":
					return "وضعیت خرید نامشخص می باشد";
				case "-902":
					return "وضعیت نا‌مشخص در‌اتصال به‌پرداخت رخ داده است، مجددا امتحان کنید";
				case "-999":
					return "خطای سیستمی رخ داد";

				default:
					return "";
			}
		}


	}
}
